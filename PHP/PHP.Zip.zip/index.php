<?php
    if(isset($_GET['Amount'])&&isset($_GET['Description'])&&isset($_GET['Email'])&&isset($_GET['Mobile'])&&isset($_GET['Merchand_ID'])&&isset($_GET['Start'])){
        $MerchantID = $_GET['Merchand_ID'];
        $Amount = $_GET['Amount']; 
        $Description =$_GET['Description'] ;
        $Email = $_GET['Email'] ;
        $Mobile = $_GET['Mobile'];
        $CallbackURL = $_GET['Start']."/verify.php/?email=$Email&Amount=$Amount&phone=$Mobile&MerchantID=$MerchantID";
        $client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
        $result = $client->PaymentRequest(
        [
        'MerchantID' => $MerchantID,
        'Amount' => $Amount,
        'Description' => $Description,
        'Email' => $Email,
        'Mobile' => $Mobile,
        'CallbackURL' => $CallbackURL,
        ]
        );
        if ($result->Status == 100) {
        Header('Location: https://www.zarinpal.com/pg/StartPay/'.$result->Authority);
        } else {
        echo'ERR: '.$result->Status;
        }
    }else{
       echo 'PHP Eror 405';
    }