<?php
$MerchantID = $_GET['MerchantID'];
$Amount = $_GET['Amount'];
$Authority = $_GET['Authority'];
if ($_GET['Status'] == 'OK') {
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
$result = $client->PaymentVerification(['MerchantID' => $MerchantID,'Authority' => $Authority,'Amount' => $Amount,]);
    $a = array();
    array_push($a,array('Status' =>  $result->Status ,'Kod_Tarakonesh' =>$result->RefID));
    echo json_encode($a);
} else {
    $a = array();
    array_push($a,array('Status' =>  $result->Status ,'Kod_Tarakonesh' =>$result->RefID));
    echo json_encode($a);
}